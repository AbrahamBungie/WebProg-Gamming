package com.uacm.web.services;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.javafaker.Faker;
import com.uacm.web.model.BancoEmisor;
import com.uacm.web.model.InformacionFacturacionEntity;
import com.uacm.web.model.TarjetaCreditoEntity;
import com.uacm.web.model.TipoTarjeta;
import com.uacm.web.model.TitularTarjetaEntity;
import com.uacm.web.model.TransaccionPagoEntity;
import com.uacm.web.repository.InformacionFacturacionRepository;
import com.uacm.web.repository.TarjetaCreditoRepository;
import com.uacm.web.repository.TitularTarjetaRepository;
import com.uacm.web.repository.TransaccionPagoRepository;

@Service
public class GeneradorDatosServices {
    private final TarjetaCreditoRepository tarjetaCreditoRepository;
    private final TitularTarjetaRepository titularTarjetaRepository;
    private final InformacionFacturacionRepository informacionFacturacionRepository;
    private final TransaccionPagoRepository transaccionPagoRepository;

    @Autowired
    public GeneradorDatosServices(TarjetaCreditoRepository tarjetaCreditoRepository,
                                TitularTarjetaRepository titularTarjetaRepository,
                                InformacionFacturacionRepository informacionFacturacionRepository,
                                TransaccionPagoRepository transaccionPagoRepository) {
        this.tarjetaCreditoRepository = tarjetaCreditoRepository;
        this.titularTarjetaRepository = titularTarjetaRepository;
        this.informacionFacturacionRepository = informacionFacturacionRepository;
        this.transaccionPagoRepository = transaccionPagoRepository;
    }

    public void generarDatosDePrueba(int cantidad) {
        // Especifica la localización para datos en español de México
        Faker faker = new Faker(new Locale("es", "MX"));

        for (int i = 0; i < cantidad; i++) {
            // Genera instancias de tus entidades con datos aleatorios
            InformacionFacturacionEntity informacionFacturacion = generarInformacionFacturacionAleatoria(faker);
            TitularTarjetaEntity titularTarjeta = generarTitularTarjetaAleatorio(faker);
            TarjetaCreditoEntity tarjetaCredito = generarTarjetaCreditoAleatoria(titularTarjeta, faker);
            TransaccionPagoEntity transaccionPago = generarTransaccionPagoAleatoria(titularTarjeta, informacionFacturacion, tarjetaCredito, faker);

            // Guarda las instancias en la base de datos
            informacionFacturacionRepository.save(informacionFacturacion);
            titularTarjetaRepository.save(titularTarjeta);
            tarjetaCreditoRepository.save(tarjetaCredito);
            transaccionPagoRepository.save(transaccionPago);
        }
    }

    // Métodos para generar datos aleatorios de cada entidad
    private InformacionFacturacionEntity generarInformacionFacturacionAleatoria(Faker faker) {
        InformacionFacturacionEntity informacionFacturacion = new InformacionFacturacionEntity();
        informacionFacturacion.setCalle(faker.address().streetName());
        informacionFacturacion.setNumero(faker.address().buildingNumber());
        informacionFacturacion.setColonia(faker.address().secondaryAddress());
        informacionFacturacion.setCodigoPostal(faker.address().zipCode());
        informacionFacturacion.setCiudad(faker.address().city());
        informacionFacturacion.setEstado(faker.address().state());
        return informacionFacturacion;
    }

    private TitularTarjetaEntity generarTitularTarjetaAleatorio(Faker faker) {
        TitularTarjetaEntity titularTarjeta = new TitularTarjetaEntity();
        titularTarjeta.setNombre(faker.name().firstName());
        titularTarjeta.setApellidoPaterno(faker.name().lastName());
        titularTarjeta.setApellidoMaterno(faker.name().lastName());
        titularTarjeta.setCorreoElectronico(faker.internet().emailAddress());
        titularTarjeta.setNumeroTelefono(faker.phoneNumber().phoneNumber());
        return titularTarjeta;
    }

    private TarjetaCreditoEntity generarTarjetaCreditoAleatoria(TitularTarjetaEntity titularTarjeta, Faker faker) {
        TarjetaCreditoEntity tarjetaCredito = new TarjetaCreditoEntity();

        tarjetaCredito.setFechaVencimiento(generarFechaVencimiento(faker));

        String numeroTarjeta = generarNumeroTarjetaValido(faker);
        tarjetaCredito.setNumeroTarjeta(numeroTarjeta);
        tarjetaCredito.setCodigoSeguridad(faker.number().digits(3));
        tarjetaCredito.setLimiteCredito(faker.number().randomDouble(2, 100, 10000));
        tarjetaCredito.setTipoTarjeta(obtenerTipoTarjeta(numeroTarjeta));
        tarjetaCredito.setBancoEmisor(obtenerBancoEmisor(numeroTarjeta));
        tarjetaCredito.setTitularTarjeta(titularTarjeta);

        return tarjetaCredito;
    }

    private String generarNumeroTarjetaValido(Faker faker) {
        // Genera un número de tarjeta válido utilizando un generador en línea o algoritmo conocido
        String numeroTarjeta = generarNumeroTarjetaAleatorio(faker);
        // Aplica el algoritmo de Luhn para verificar la validez
        if (!esNumeroTarjetaValido(numeroTarjeta)) {
            // Si no es válido, intenta generar otro número
            return generarNumeroTarjetaValido(faker);
        }
        return numeroTarjeta;
    }

    private String generarNumeroTarjetaAleatorio(Faker faker) {
        int primerDigito = generarPrimerDigito(faker);
        String digitosBanco = faker.number().digits(5);
        String digitosRestantes = faker.number().digits(10);

        if (primerDigito == 37 || primerDigito == 34) {
            return String.format("%d%s%s", primerDigito, digitosBanco, digitosRestantes);
        } else {
            return String.format("%d%s%s", primerDigito, digitosBanco, digitosRestantes.substring(1));
        }
    }

    private int generarPrimerDigito(Faker faker) {
    	int[] probabilidades = {4, 5, 6, 2, 3, 4, 5, 6, 1};
        int indice = probabilidades.length - 1;
        int totalProbabilidades = Arrays.stream(probabilidades).sum();
        int numeroAleatorio = faker.number().numberBetween(1, totalProbabilidades + 1);

        for (int i = 0; i < probabilidades.length; i++) {
            if (numeroAleatorio <= probabilidades[i]) {
                indice = i;
                break;
            }
            numeroAleatorio -= probabilidades[i];
        }

        return probabilidades[indice];
    }

    private boolean esNumeroTarjetaValido(String numeroTarjeta) {
        // Implementa el algoritmo de Luhn (MOD 10) para verificar la validez del número de tarjeta
        int sum = 0;
        boolean alternate = false;
        for (int i = numeroTarjeta.length() - 1; i >= 0; i--) {
            int digit = Integer.parseInt(numeroTarjeta.substring(i, i + 1));
            if (alternate) {
                digit *= 2;
                if (digit > 9) {
                    digit = digit % 10 + 1;
                }
            }
            sum += digit;
            alternate = !alternate;
        }
        return sum % 10 == 0;
    }

    private String generarFechaVencimiento(Faker faker) {
        LocalDate fechaActual = LocalDate.now();
        int mesesAlFuturo = faker.number().numberBetween(1, 25);
        LocalDate fechaVencimiento = fechaActual.plusMonths(mesesAlFuturo);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yy");
        return fechaVencimiento.format(formatter);
    }

    private TransaccionPagoEntity generarTransaccionPagoAleatoria(TitularTarjetaEntity titularTarjeta,
                                                                 InformacionFacturacionEntity informacionFacturacion,
                                                                 TarjetaCreditoEntity tarjetaCredito, Faker faker) {
        TransaccionPagoEntity transaccionPago = new TransaccionPagoEntity();
        transaccionPago.setTitularTarjeta(titularTarjeta);
        transaccionPago.setInformacionFacturacion(informacionFacturacion);
        transaccionPago.setTarjetaCredito(tarjetaCredito);
        transaccionPago.setMonto(faker.number().randomDouble(2, 10, 500));
        transaccionPago.setFecha(new Date());
        return transaccionPago;
    }

    private TipoTarjeta obtenerTipoTarjeta(String numeroTarjeta) {
        if (numeroTarjeta.startsWith("4")) {
            return TipoTarjeta.VISA;
        } else if (numeroTarjeta.startsWith("5")) {
            return TipoTarjeta.MASTERCARD;
        } else if (numeroTarjeta.startsWith("37") || numeroTarjeta.startsWith("34")) {
            return TipoTarjeta.AMERICAN_EXPRESS;
        } else {
            return TipoTarjeta.VISA; 
        }
    }

    private BancoEmisor obtenerBancoEmisor(String numeroTarjeta) {
        String primerosDigitos = numeroTarjeta.substring(0, 2);

        if (primerosDigitos.startsWith("4")) {
            return BancoEmisor.BANAMEX;
        } else if (primerosDigitos.startsWith("5")) {
            return BancoEmisor.BBVA;
        } else if (primerosDigitos.startsWith("6")) {
            return BancoEmisor.SANTANDER;
        } else if (primerosDigitos.equals("37") || primerosDigitos.equals("34")) {
            return BancoEmisor.AMERICAN_EXPRESS;
        } else if (primerosDigitos.startsWith("2")) {
            return BancoEmisor.BANORTE;
        } else {
            return BancoEmisor.BBVA;
        }
    }
}
