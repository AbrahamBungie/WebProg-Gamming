package com.uacm.web.model;

public enum TipoTarjeta {
	VISA,
	MASTERCARD,
	AMERICAN_EXPRESS
}
