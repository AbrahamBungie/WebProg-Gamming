package com.uacm.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.uacm.web.services.GeneradorDatosServices;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class FormularioPagoApplication {

    @Autowired
    private GeneradorDatosServices generadorDatosServices;

    public static void main(String[] args) {
        SpringApplication.run(FormularioPagoApplication.class, args);
    }

    @PostConstruct
    public void init() {
        generadorDatosServices.generarDatosDePrueba(20);
    }
}





