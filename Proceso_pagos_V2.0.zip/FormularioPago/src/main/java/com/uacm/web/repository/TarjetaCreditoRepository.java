package com.uacm.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uacm.web.model.TarjetaCreditoEntity;

@Repository
public interface TarjetaCreditoRepository extends JpaRepository<TarjetaCreditoEntity, Long>{
	
	TarjetaCreditoEntity findByNumeroTarjeta(String numeroTarjeta);
}
