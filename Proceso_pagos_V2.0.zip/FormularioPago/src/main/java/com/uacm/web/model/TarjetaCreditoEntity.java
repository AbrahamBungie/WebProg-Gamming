package com.uacm.web.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tarjeta_credito")
public class TarjetaCreditoEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "numero_tarjeta")
	private String numeroTarjeta;
	
	@Column(name = "fecha_vencimiento")
	private String fechaVencimiento;
	
	@Column(name = "codigo_seguridad")
	private String codigoSeguridad;
	
	@Column(name = "limiteCredito", columnDefinition = "numeric(10,2)")
	private double limiteCredito;
	
	@Enumerated(EnumType.STRING)
	private TipoTarjeta tipoTarjeta;
	
	@Enumerated(EnumType.STRING)
	private BancoEmisor bancoEmisor;
	
    @ManyToOne
    @JoinColumn(name = "titular_tarjeta_id")
    private TitularTarjetaEntity titularTarjeta;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public String getFechaVencimiento() {
		return fechaVencimiento;
	}

	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	public String getCodigoSeguridad() {
		return codigoSeguridad;
	}

	public void setCodigoSeguridad(String codigoSeguridad) {
		this.codigoSeguridad = codigoSeguridad;
	}

	public double getLimiteCredito() {
		return limiteCredito;
	}

	public void setLimiteCredito(double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}

	public TitularTarjetaEntity getTitularTarjeta() {
		return titularTarjeta;
	}

	public void setTitularTarjeta(TitularTarjetaEntity titularTarjeta) {
		this.titularTarjeta = titularTarjeta;
	}

	public TipoTarjeta getTipoTarjeta() {
		return tipoTarjeta;
	}

	public void setTipoTarjeta(TipoTarjeta tipoTarjeta) {
		this.tipoTarjeta = tipoTarjeta;
	}

	public BancoEmisor getBancoEmisor() {
		return bancoEmisor;
	}

	public void setBancoEmisor(BancoEmisor bancoEmisor) {
		this.bancoEmisor = bancoEmisor;
	}
}
