package com.uacm.web.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "transaccion_pago")
public class TransaccionPagoEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@ManyToOne
	@JoinColumn(name = "titular_tarjeta_id")
	private TitularTarjetaEntity titularTarjeta;
	
	@ManyToOne
    @JoinColumn(name = "informacion_facturacion_id")
    private InformacionFacturacionEntity informacionFacturacion;
	
    @ManyToOne
    @JoinColumn(name = "tarjeta_credito_id")
    private TarjetaCreditoEntity tarjetaCredito;
    
    @Column(name = "monto")
    private double monto;
    
    @Column(name = "fecha")
    private Date fecha;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TitularTarjetaEntity getTitularTarjeta() {
		return titularTarjeta;
	}

	public void setTitularTarjeta(TitularTarjetaEntity titularTarjeta) {
		this.titularTarjeta = titularTarjeta;
	}

	public InformacionFacturacionEntity getInformacionFacturacion() {
		return informacionFacturacion;
	}

	public void setInformacionFacturacion(InformacionFacturacionEntity informacionFacturacion) {
		this.informacionFacturacion = informacionFacturacion;
	}

	public TarjetaCreditoEntity getTarjetaCredito() {
		return tarjetaCredito;
	}

	public void setTarjetaCredito(TarjetaCreditoEntity tarjetaCredito) {
		this.tarjetaCredito = tarjetaCredito;
	}

	public double getMonto() {
		return monto;
	}

	public void setMonto(double monto) {
		this.monto = monto;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
}
