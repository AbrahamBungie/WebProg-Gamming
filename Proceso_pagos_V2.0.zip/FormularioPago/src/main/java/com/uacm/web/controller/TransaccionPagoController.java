package com.uacm.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.uacm.web.services.TransaccionPagoServices;

@Controller
@RequestMapping("/pagos")
public class TransaccionPagoController {

    private final TransaccionPagoServices transaccionPagoServices;

    @Autowired
    public TransaccionPagoController(TransaccionPagoServices transaccionPagoServices) {
        this.transaccionPagoServices = transaccionPagoServices;
    }

    @GetMapping("/formulario")
    public String mostrarFormulario() {
        return "formulario-pago"; 
    }

    @PostMapping("/procesar")
    public String procesarPago(String numeroTarjeta, String fechaVencimiento, String codigoSeguridad, String nombreCompletoTitular, 
    		@RequestParam(defaultValue = "6000.0") double monto, Model model) {
        boolean transaccionExitosa = transaccionPagoServices.procesarPago(numeroTarjeta, fechaVencimiento, codigoSeguridad, nombreCompletoTitular, monto);

        if (transaccionExitosa) {
            model.addAttribute("mensaje", "Transacción exitosa");
        } else {
            model.addAttribute("mensaje", "No se pudo procesar la transacción");
        }

        return "resultado-pago"; 
    }
}
