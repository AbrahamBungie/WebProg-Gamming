package com.uacm.web.services;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uacm.web.model.TarjetaCreditoEntity;
import com.uacm.web.model.TitularTarjetaEntity;
import com.uacm.web.repository.TarjetaCreditoRepository;

@Service
public class TransaccionPagoServices {
	private final TarjetaCreditoRepository tarjetaCreditoRepository;
	
	@Autowired
	public TransaccionPagoServices(TarjetaCreditoRepository tarjetaCreditoRepository) {
		this.tarjetaCreditoRepository = tarjetaCreditoRepository;
	}
	
	public boolean procesarPago(String numeroTarjeta, String fechaVencimiento, String codigoSeguridad, String nombreCompletoTitular, double monto) {
		boolean esTransaccionExitosa = false;
		
		// Paso 1. Obtener la información de la tarjeta desde la BD
		TarjetaCreditoEntity tarjeta = tarjetaCreditoRepository.findByNumeroTarjeta(numeroTarjeta);
		
		// Paso 2. Validar datos
		if(tarjeta != null && datosValidos(fechaVencimiento, codigoSeguridad, monto, tarjeta)) {
			TitularTarjetaEntity titular = tarjeta.getTitularTarjeta();
			
			String nombreCompletoBD = obtenerNombreCompleto(titular);
			
			// Paso 3. Actualizar el saldo en la BD
			double nuevoLimite = tarjeta.getLimiteCredito() - monto;
			tarjeta.setLimiteCredito(nuevoLimite);
			tarjetaCreditoRepository.save(tarjeta);
			
			esTransaccionExitosa = true;
		}
		
		return esTransaccionExitosa;
	}
	
	private boolean datosValidos(String fechaVencimiento, String codigoSeguridad, double monto, TarjetaCreditoEntity tarjeta) {
		// Simulamos la validación de datos muy simplificado
		// Verifica que la fecha de vencimiento esté en el futuro el código de seguridad sea correcto y hay saldo suficiente
		return fechaVencimientoValida(fechaVencimiento) && codigoSeguridadCorrecto(codigoSeguridad) && limiteCreditoSuficiente(monto, tarjeta.getLimiteCredito());
	}
	
	private boolean fechaVencimientoValida(String fechaVencimiento) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yy");
	    YearMonth fechaVencimientoTarjeta = YearMonth.parse(fechaVencimiento, formatter);
	    return YearMonth.now().isBefore(fechaVencimientoTarjeta);
	}
	
	private boolean codigoSeguridadCorrecto(String codigoSeguridad) {
		return codigoSeguridad.length() == 3;
	}
	
	private boolean limiteCreditoSuficiente(double monto, double limiteCredito) {
		return limiteCredito >= monto;
	}
	
	private String obtenerNombreCompleto(TitularTarjetaEntity titular) {
		if(titular != null) {
			return titular.getNombre() + " " + titular.getApellidoPaterno() + " " + titular.getApellidoMaterno();
		}
		
		return "";
	}
}