package com.uacm.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.uacm.web.model.Producto;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/carrito")
public class CarritoController {

    private List<Producto> productosSeleccionados = new ArrayList<>(); // Aquí se almacenan los productos seleccionados

    // Constructor para simular productos seleccionados (puedes omitirlo si ya tienes tus productos)
    public CarritoController() {
        // Simulación de productos seleccionados
        productosSeleccionados.add(new Producto(1L, "NFSMW", 10.0, 2, "/images/nfsmw.jpg"));
        productosSeleccionados.add(new Producto(2L, "Halo Reach", 15.0, 1, "/images/halo3.jpg"));
        productosSeleccionados.add(new Producto(3L, "Halo 3", 20.0, 3, "/images/reach.jpg"));
    }

    @GetMapping
    public String verCarrito(Model model) {
        // Calcular el precio total de cada producto y el precio total general
        double totalPrecio = 0.0;
        for (Producto producto : productosSeleccionados) {
            producto.setPrecioTotal(producto.calcularPrecioTotal());
            totalPrecio += producto.getPrecioTotal();
        }

        model.addAttribute("productos", productosSeleccionados);
        model.addAttribute("totalPrecio", totalPrecio);

        return "carrito";
    }

    @PostMapping("/agregar")
    public String agregarProducto(@ModelAttribute("producto") Producto producto) {
        productosSeleccionados.add(producto);
        return "redirect:/carrito";
    }

    @PostMapping("/eliminar")
    public String eliminarProducto(@RequestParam int indice) {
        if (indice >= 0 && indice < productosSeleccionados.size()) {
            productosSeleccionados.remove(indice);
        }
        return "redirect:/carrito";
    }

    // Otros métodos para procesar información del cliente, confirmar compra, mostrar historial, gestionar cupones, etc.
}

