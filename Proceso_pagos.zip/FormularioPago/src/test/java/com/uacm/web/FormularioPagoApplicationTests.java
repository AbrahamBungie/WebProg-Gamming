package com.uacm.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioPagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
