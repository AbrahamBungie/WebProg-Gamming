package com.uacm.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uacm.web.services.TransaccionPagoServices;

@Controller
@RequestMapping("/pagos")
public class TransaccionPagoController {

    private final TransaccionPagoServices transaccionPagoServices;

    @Autowired
    public TransaccionPagoController(TransaccionPagoServices transaccionPagoServices) {
        this.transaccionPagoServices = transaccionPagoServices;
    }

    @GetMapping("/formulario")
    public String mostrarFormulario() {
        return "formulario-pago"; // Nombre de la plantilla de Thymeleaf (puedes cambiarlo según tus necesidades)
    }

    @PostMapping("/procesar")
    public String procesarPago(String numeroTarjeta, String fechaVencimiento, String codigoSeguridad, double monto, Model model) {
        boolean transaccionExitosa = transaccionPagoServices.procesarPago(numeroTarjeta, fechaVencimiento, codigoSeguridad, monto);

        if (transaccionExitosa) {
            model.addAttribute("mensaje", "Transacción exitosa");
        } else {
            model.addAttribute("mensaje", "No se pudo procesar la transacción");
        }

        return "resultado-pago"; // Nombre de la plantilla de Thymeleaf para mostrar el resultado
    }
}
