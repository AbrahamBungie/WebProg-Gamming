package com.uacm.web.model;

public enum BancoEmisor {
	BANAMEX,
	BBVA,
	SANTANDER,
	BANORTE,
	AMERICAN_EXPRESS
}
