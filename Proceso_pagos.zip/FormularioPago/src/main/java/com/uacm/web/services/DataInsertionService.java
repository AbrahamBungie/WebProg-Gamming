package com.uacm.web.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uacm.web.model.InformacionFacturacionEntity;
import com.uacm.web.model.TarjetaCreditoEntity;
import com.uacm.web.model.TitularTarjetaEntity;
import com.uacm.web.model.TransaccionPagoEntity;
import com.uacm.web.repository.InformacionFacturacionRepository;
import com.uacm.web.repository.TarjetaCreditoRepository;
import com.uacm.web.repository.TitularTarjetaRepository;
import com.uacm.web.repository.TransaccionPagoRepository;

@Service
public class DataInsertionService {

    private final TarjetaCreditoRepository tarjetaCreditoRepository;
    private final TitularTarjetaRepository titularTarjetaRepository;
    private final InformacionFacturacionRepository informacionFacturacionRepository;
    private final TransaccionPagoRepository transaccionPagoRepository;

    @Autowired
    public DataInsertionService(
            TarjetaCreditoRepository tarjetaCreditoRepository,
            TitularTarjetaRepository titularTarjetaRepository,
            InformacionFacturacionRepository informacionFacturacionRepository,
            TransaccionPagoRepository transaccionPagoRepository) {
        this.tarjetaCreditoRepository = tarjetaCreditoRepository;
        this.titularTarjetaRepository = titularTarjetaRepository;
        this.informacionFacturacionRepository = informacionFacturacionRepository;
        this.transaccionPagoRepository = transaccionPagoRepository;
    }

    @Transactional
    public void insertSampleData() {
        // Crear un titular de tarjeta
        TitularTarjetaEntity titularTarjeta = new TitularTarjetaEntity();
        titularTarjeta.setNombre("John");
        titularTarjeta.setApellidoPaterno("Doe");
        titularTarjeta.setCorreoElectronico("john.doe@example.com");
        titularTarjeta.setNumeroTelefono("1234567890");
        titularTarjetaRepository.save(titularTarjeta);

        // Crear información de facturación
        InformacionFacturacionEntity informacionFacturacion = new InformacionFacturacionEntity();
        informacionFacturacion.setCalle("Calle Principal");
        informacionFacturacion.setNumero("123");
        informacionFacturacion.setColonia("Centro");
        informacionFacturacion.setCodigoPostal("12345");
        informacionFacturacion.setCiudad("Ciudad");
        informacionFacturacion.setEstado("Estado");
        informacionFacturacionRepository.save(informacionFacturacion);

        // Crear tarjeta de crédito
        TarjetaCreditoEntity tarjetaCredito = new TarjetaCreditoEntity();
        tarjetaCredito.setNumeroTarjeta("1234567890123456");
        tarjetaCredito.setFechaVencimiento("12/25");
        tarjetaCredito.setCodigoSeguridad("123");
        tarjetaCredito.setSaldo(1000.0);
        tarjetaCredito.setTitularTarjeta(titularTarjeta);
        tarjetaCreditoRepository.save(tarjetaCredito);

        // Realizar una transacción de pago
        TransaccionPagoEntity transaccionPago = new TransaccionPagoEntity();
        transaccionPago.setTitularTarjeta(titularTarjeta);
        transaccionPago.setInformacionFacturacion(informacionFacturacion);
        transaccionPago.setTarjetaCredito(tarjetaCredito);
        transaccionPago.setMonto(50.0);
        transaccionPago.setFecha(new Date());
        transaccionPagoRepository.save(transaccionPago);
    }
}

