package com.uacm.web.services;

import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.javafaker.Faker;
import com.uacm.web.model.BancoEmisor;
import com.uacm.web.model.InformacionFacturacionEntity;
import com.uacm.web.model.TarjetaCreditoEntity;
import com.uacm.web.model.TipoTarjeta;
import com.uacm.web.model.TitularTarjetaEntity;
import com.uacm.web.model.TransaccionPagoEntity;
import com.uacm.web.repository.InformacionFacturacionRepository;
import com.uacm.web.repository.TarjetaCreditoRepository;
import com.uacm.web.repository.TitularTarjetaRepository;
import com.uacm.web.repository.TransaccionPagoRepository;

@Service
public class GeneradorDatosServices {
    private final TarjetaCreditoRepository tarjetaCreditoRepository;
    private final TitularTarjetaRepository titularTarjetaRepository;
    private final InformacionFacturacionRepository informacionFacturacionRepository;
    private final TransaccionPagoRepository transaccionPagoRepository;

    @Autowired
    public GeneradorDatosServices(TarjetaCreditoRepository tarjetaCreditoRepository,
                                TitularTarjetaRepository titularTarjetaRepository,
                                InformacionFacturacionRepository informacionFacturacionRepository,
                                TransaccionPagoRepository transaccionPagoRepository) {
        this.tarjetaCreditoRepository = tarjetaCreditoRepository;
        this.titularTarjetaRepository = titularTarjetaRepository;
        this.informacionFacturacionRepository = informacionFacturacionRepository;
        this.transaccionPagoRepository = transaccionPagoRepository;
    }

    public void generarDatosDePrueba(int cantidad) {
        // Especifica la localización para datos en español de México
        Faker faker = new Faker(new Locale("es", "MX"));

        for (int i = 0; i < cantidad; i++) {
            // Genera instancias de tus entidades con datos aleatorios
            InformacionFacturacionEntity informacionFacturacion = generarInformacionFacturacionAleatoria(faker);
            TitularTarjetaEntity titularTarjeta = generarTitularTarjetaAleatorio(faker);
            TarjetaCreditoEntity tarjetaCredito = generarTarjetaCreditoAleatoria(titularTarjeta, faker);
            TransaccionPagoEntity transaccionPago = generarTransaccionPagoAleatoria(titularTarjeta, informacionFacturacion, tarjetaCredito, faker);

            // Guarda las instancias en la base de datos
            informacionFacturacionRepository.save(informacionFacturacion);
            titularTarjetaRepository.save(titularTarjeta);
            tarjetaCreditoRepository.save(tarjetaCredito);
            transaccionPagoRepository.save(transaccionPago);
        }
    }

    // Métodos para generar datos aleatorios de cada entidad
    private InformacionFacturacionEntity generarInformacionFacturacionAleatoria(Faker faker) {
        InformacionFacturacionEntity informacionFacturacion = new InformacionFacturacionEntity();
        informacionFacturacion.setCalle(faker.address().streetName());
        informacionFacturacion.setNumero(faker.address().buildingNumber());
        informacionFacturacion.setColonia(faker.address().secondaryAddress());
        informacionFacturacion.setCodigoPostal(faker.address().zipCode());
        informacionFacturacion.setCiudad(faker.address().city());
        informacionFacturacion.setEstado(faker.address().state());
        return informacionFacturacion;
    }

    private TitularTarjetaEntity generarTitularTarjetaAleatorio(Faker faker) {
        TitularTarjetaEntity titularTarjeta = new TitularTarjetaEntity();
        titularTarjeta.setNombre(faker.name().firstName());
        titularTarjeta.setApellidoPaterno(faker.name().lastName());
        titularTarjeta.setApellidoMaterno(faker.name().lastName());
        titularTarjeta.setCorreoElectronico(faker.internet().emailAddress());
        titularTarjeta.setNumeroTelefono(faker.phoneNumber().phoneNumber());
        return titularTarjeta;
    }

    private TarjetaCreditoEntity generarTarjetaCreditoAleatoria(TitularTarjetaEntity titularTarjeta, Faker faker) {
        TarjetaCreditoEntity tarjetaCredito = new TarjetaCreditoEntity();
        tarjetaCredito.setNumeroTarjeta(generarNumeroTarjeta(titularTarjeta, faker));
        tarjetaCredito.setFechaVencimiento(faker.business().creditCardExpiry());
        tarjetaCredito.setCodigoSeguridad(faker.number().digits(3));
        tarjetaCredito.setSaldo(faker.number().randomDouble(2, 100, 10000));
        tarjetaCredito.setTipoTarjeta(obtenerTipoTarjeta(tarjetaCredito.getNumeroTarjeta()));
        tarjetaCredito.setBancoEmisor(obtenerBancoEmisor(tarjetaCredito.getNumeroTarjeta()));
        tarjetaCredito.setTitularTarjeta(titularTarjeta);
        return tarjetaCredito;
    }

    private TransaccionPagoEntity generarTransaccionPagoAleatoria(TitularTarjetaEntity titularTarjeta,
                                                                 InformacionFacturacionEntity informacionFacturacion,
                                                                 TarjetaCreditoEntity tarjetaCredito, Faker faker) {
        TransaccionPagoEntity transaccionPago = new TransaccionPagoEntity();
        transaccionPago.setTitularTarjeta(titularTarjeta);
        transaccionPago.setInformacionFacturacion(informacionFacturacion);
        transaccionPago.setTarjetaCredito(tarjetaCredito);
        transaccionPago.setMonto(faker.number().randomDouble(2, 10, 500));
        // Establecer la fecha actual
        transaccionPago.setFecha(new Date());
        return transaccionPago;
    }

    private String generarNumeroTarjeta(TitularTarjetaEntity titularTarjeta, Faker faker) {
        // Genera el primer dígito según tus criterios
        int primerDigito = Integer.parseInt(String.valueOf(faker.number().numberBetween(1, 4)));

        // Genera los siguientes dígitos
        String digitosBanco = faker.number().digits(5);

        // Genera el resto de los dígitos aleatoriamente
        String digitosRestantes = faker.number().digits(10);

        // Combina los dígitos
        return String.format("%d%s%s", primerDigito, digitosBanco, digitosRestantes);
    }

    private TipoTarjeta obtenerTipoTarjeta(String numeroTarjeta) {
        // Lógica para determinar el tipo de tarjeta según el número de tarjeta
        // Puedes implementar tus propias reglas aquí
        // En este ejemplo, simplemente devuelvo MASTERCARD si el primer dígito es 2
        return numeroTarjeta.startsWith("2") ? TipoTarjeta.MASTERCARD : TipoTarjeta.VISA;
    }

    private BancoEmisor obtenerBancoEmisor(String numeroTarjeta) {
        // Lógica para determinar el banco emisor según el número de tarjeta
        // Puedes implementar tus propias reglas aquí
        // En este ejemplo, devuelvo BANAMEX si el segundo dígito es 4
        return numeroTarjeta.charAt(1) == '4' ? BancoEmisor.BANAMEX : BancoEmisor.BBVA;
    }
}
