package com.uacm.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.uacm.web.services.DataInsertionService;

@SpringBootApplication
public class FormularioPagoApplication {

	@Autowired
	private DataInsertionService dataInsertionService;
	
	public static void main(String[] args) {
		SpringApplication.run(FormularioPagoApplication.class, args);
	}
	
    public void run(String... args) {
        dataInsertionService.insertSampleData();
    }
}
