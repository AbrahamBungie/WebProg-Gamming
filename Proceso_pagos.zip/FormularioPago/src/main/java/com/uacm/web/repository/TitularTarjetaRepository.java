package com.uacm.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uacm.web.model.TitularTarjetaEntity;

@Repository
public interface TitularTarjetaRepository extends JpaRepository<TitularTarjetaEntity, Long>{

}
