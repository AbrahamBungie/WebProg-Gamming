package com.uacm.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uacm.web.model.TransaccionPagoEntity;

@Repository
public interface TransaccionPagoRepository extends JpaRepository<TransaccionPagoEntity, Long>{

}
